<tbody {{ $attributes->merge(['class' => 'bg-white dark:bg-black']) }}>
    {{ $slot }}
</tbody>
